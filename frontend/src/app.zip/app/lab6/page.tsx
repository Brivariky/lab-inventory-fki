import LabPageTemplate from "../../components/LabPageTemplate";

export default function Page() {
  return <LabPageTemplate labId={6} labName="LAB SIC" />;
}
