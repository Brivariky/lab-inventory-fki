import LabPageTemplate from "../../components/LabPageTemplate";

export default function Page() {
  return <LabPageTemplate labId={2} labName="LAB LABORAN" />;
}
