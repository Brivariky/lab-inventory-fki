import LabPageTemplate from "../../components/LabPageTemplate";

export default function Page() {
  return <LabPageTemplate labId={1} labName="LAB FKI" />;
}
