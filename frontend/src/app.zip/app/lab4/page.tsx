import LabPageTemplate from "../../components/LabPageTemplate";

export default function Page() {
  return <LabPageTemplate labId={4} labName="LAB RPL" />;
}
