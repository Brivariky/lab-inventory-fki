import LabPageTemplate from "../../components/LabPageTemplate";

export default function Page() {
  return <LabPageTemplate labId={3} labName="LAB SI" />;
}
